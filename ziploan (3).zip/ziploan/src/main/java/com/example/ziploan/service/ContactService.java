package com.example.ziploan.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ziploan.entity.Contact;
import com.example.ziploan.repository.ContactRepo;

@Service
public class ContactService {

	@Autowired
	ContactRepo contactRepo;
	
	
	public List<Contact> getContacts(String firstName, String lastName, String email)   
	{  
		if(firstName != null) {
			return contactRepo.findByFirstName(firstName);
		}
		else if(lastName != null) {
			return contactRepo.findByFirstName(lastName);
		}
		else if (email != null){
			return contactRepo.findByEmail(email);
		}
		
	List<Contact> contacts = new ArrayList<Contact>();  
	contactRepo.findAll().forEach(contact1 -> contacts.add(contact1));  
	return contacts;  
	}  
	
	//getting a specific record by using the method findById() of CrudRepository  
	public  Contact getContactById(Long id)   
	{  
	return contactRepo.findById(id).get();  
	}  


	
	
	
	
	public void save(Contact contact)   
	{  
		contactRepo.save(contact);  
	}  
	
	//deleting a specific record by using the method deleteById() of CrudRepository  
	public void delete(long id)   
	{  
		contactRepo.deleteById(id);  
	}  
	
	//updating a record  
	public Contact update(Contact updatedContact, long id)   
	{  
//	  contactRepo.save(contact); 
	  
	  Contact existingContact = contactRepo.findById(id).orElse(null);
      if (existingContact != null) {
          existingContact.setFirstName(updatedContact.getFirstName());
          existingContact.setLastName(updatedContact.getLastName());
          existingContact.setEmail(updatedContact.getEmail());
          existingContact.setPhone(updatedContact.getPhone());
          return contactRepo.save(existingContact);
      }
      return null;
	  
	  
	}  
	
	
}
