package com.example.ziploan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZiploanApplicationTests {

	@Test
	void contextLoads() {
	}

}
