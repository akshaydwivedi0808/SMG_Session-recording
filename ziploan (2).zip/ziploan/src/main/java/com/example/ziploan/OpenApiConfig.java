package com.example.ziploan;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI usersMicroserviceOpenAPI() {
        return new OpenAPI()
                .info(new Info().title("Your API Title")
                                 .description("Your API Description")
                                 .version("1.0"));
    }
}



//
//import org.springframework.stereotype.Component;
//
//import io.swagger.v3.oas.models.info.Contact;
//
////import com.example.ziploan.entity.Contact;
//
//import io.swagger.v3.oas.models.info.Info;
//import io.swagger.v3.oas.models.info.License;
//import io.swagger.v3.oas.models.servers.Server;
//
//@Component
//public class ApiDocumentation {
//
//	
//		Contact contact = new Contact();
//		contact.setEmail("abc@yahoo.com");
//		contact.setName("Eric Cabrel TIOGO");
//		contact.setUrl("https://my-awesome-api.com");
//
//		Server localServer = new Server();
//		localServer.setUrl("http://localhost:8000");
//		localServer.setDescription("Server URL in Local environment");
//
//		Server productionServer = new Server();
//		productionServer.setUrl("https://my-awesome-api.com");
//		productionServer.setDescription("Server URL in Production environment");
//			
//		License mitLicense = new License()
//				.name("MIT License")
//				.url("https://choosealicense.com/licenses/mit/");
//
//		Info info = new Info()
//				.title("TASK MANAGER API")
//				.contact(contact)
//				.version("1.0")
//				.description("This API exposes endpoints for users to manage their tasks.")
//				.termsOfService("https://my-awesome-api.com/terms")
//				.license(mitLicense);
//
//		return new OpenAPI()
//				.info(info)
//				.servers(List.of(localServer, productionServer));
//	}
//
//}
