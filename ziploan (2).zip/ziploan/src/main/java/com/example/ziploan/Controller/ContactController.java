package com.example.ziploan.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.ziploan.entity.Contact;
import com.example.ziploan.repository.ContactRepo;
import com.example.ziploan.service.ContactService;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@Tag(name = "Contact", description = "Manage Contacts")
@RestController
public class ContactController {
	
@Autowired
private  ContactService contactService;


@Operation(summary = "Get example resource by ID")
@ApiResponse(responseCode = "200", description = "Successful operation",
        content = @Content(mediaType = "application/json", schema = @Schema(implementation = Contact.class)))
@ApiResponse(responseCode = "404", description = "Resource not found")
	
	@GetMapping("/contact/{contactid}")  
	private Contact getContact(@PathVariable("contactid") long id)   
{  
	return contactService.getContactById(id);  
} 



	@GetMapping("/contacts")
	public List<Contact> getAllContacts(@RequestParam (required = false) String firstName,
			                            @RequestParam (required = false) String lastName,
			                            @RequestParam (required = false) String email) {
	
		return contactService.getContacts(firstName, lastName, email);
	}

	 
	
	
	//creating a delete mapping that deletes a specified book  
	@DeleteMapping("/contact/{contactid}")  
	private void deleteContact(@PathVariable("contactid") long id)   
	{  
		contactService.delete(id);  
	}  
	
	
	//creating post mapping that post the book detail in the database  
	@PostMapping("/contact")  
	private Long saveContact(@RequestBody Contact contact)   
	{  
		contactService.save(contact);  
		return contact.getId();  
	}  
	
	
	//creating put mapping that updates the book detail   
	@PutMapping("/contact/{contactid}")  
	private Contact updateContact(@RequestBody Contact contact, @PathVariable("contactid") long id)   
	{  
		contactService.update(contact, id);  
	   return contact;  
	}  





	

}
