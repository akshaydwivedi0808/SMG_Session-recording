package com.example.ziploan.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ziploan.entity.Contact;

@Repository
public interface ContactRepo extends JpaRepository<Contact, Long> {
	
	List<Contact> findByFirstName(String firstName);
    List<Contact> findByLastName(String lastName);
    List<Contact> findByEmail(String email);

}
